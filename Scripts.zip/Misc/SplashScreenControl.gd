# SplashScreenControl.gd
class_name SplashScreenControl
extends Node

@export var ShowTime: float = 5.0
# تم تغيير النوع هنا ليقبل سحب وإفلات المشهد مباشرة في المفتش
@export var NextScene: PackedScene 
@export var Content: CanvasItem

var SplashTimer: float = 0.0
var next_scene_path: String = ""

func _ready() -> void:
	# التحقق من أنك قمت بتمرير ملف المشهد في المفتش
	if NextScene:
		# استخراج المسار النصي للمشهد تلقائياً لتشغيل التحميل في الخلفية
		next_scene_path = NextScene.resource_path
		ResourceLoader.load_threaded_request(next_scene_path)
	else:
		push_error("خطأ: لم يتم سحب وإفلات أي مشهد في حقل Next Scene داخل المفتش!")

func _input(event: InputEvent) -> void:
	if event.is_pressed():
		SplashTimer = max(ShowTime, SplashTimer)

func _process(delta: float) -> void:
	SplashTimer += delta
	
	# التحقق من الجاهزية باستخدام المسار المستخرج
	if NextScene and SplashTimer > ShowTime:
		if ResourceLoader.load_threaded_get_status(next_scene_path) == ResourceLoader.THREAD_LOAD_LOADED:
			var next_level_packed_scene = ResourceLoader.load_threaded_get(next_scene_path)
			get_tree().change_scene_to_packed(next_level_packed_scene)
	
	# معالجة تأثير الظهور والتلاشي (Fade In / Fade Out)
	if Content:
		var modulate_color: Color = Content.modulate
		if SplashTimer < 1.0:
			modulate_color.a = SplashTimer
		elif SplashTimer > ShowTime - 1.0:
			modulate_color.a = 1.0 - (SplashTimer - (ShowTime - 1.0))
		else:
			modulate_color.a = 1.0
			
		Content.self_modulate = modulate_color
