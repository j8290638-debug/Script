# MainMenuController.gd
class_name MainMenuController
extends Control

@export var NextLevel: PackedScene
@export var MainMenuContainer: Control
@export var DefaultMainMenuButton: Button
@export var LevelSelectContainer: Control
@export var DefaultLevelSelectButton: Button
@export var CharacterSelector: Control # تم تحديث النوع
@export var DefaultCharacterSelectorButton: Button
@export var OptionsMenuContainer: Control
@export var LoadingScreen: Control
var CurrentlyLoadingScene: String
var SaveDataInstance: Resource # يتم التعامل معه كـ Resource الحفظ الخاص بك

@export var RedRingYesIcon: Texture2D
@export var RedRingNoIcon: Texture2D

# Stage select
@export var StagesData: Node
@export var StageTemplateButton: Button

static var Instance: MainMenuController

func _enter_tree() -> void:
	Instance = self

func _exit_tree() -> void:
	Instance = null

func _ready() -> void:
	PopulateLevelSelect()
	if ResourceLoader.exists("res://SaveData.gd") or has_node("SaveData"): # فحص أمان لمحاكاة التحميل الخاص بك
		SaveDataInstance = SaveData.Load()
		SaveDataInstance.Save()

	OptionsMenuContainer.Apply()
	ToMainMenu()
	LoadingScreen.visible = false

	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	Engine.time_scale = 1

func _process(_delta: float) -> void:
	try_process()

func try_process() -> void:
	var focus = get_viewport().gui_get_focus_owner()
	if focus == null and self.visible:
		DefaultMainMenuButton.grab_focus()

	if LoadingScreen.Returning and ResourceLoader.load_threaded_get_status(CurrentlyLoadingScene) == ResourceLoader.THREAD_LOAD_LOADED and LoadingScreen.Instance.Returning and LoadingScreen.Instance.TransitionProcess >= 1:
		var nextLevelPackedScene = ResourceLoader.load_threaded_get(CurrentlyLoadingScene)
		get_tree().change_scene_to_packed(nextLevelPackedScene)

func ToMainMenu() -> void:
	HideAll()
	MainMenuContainer.visible = true
	DefaultMainMenuButton.grab_focus()

func ToLevelSelectMenu() -> void:
	HideAll()
	CharacterSelector.PreviousMenu = MainMenuContainer
	CharacterSelector.NextMenu = LevelSelectContainer
	CharacterSelector.visible = true
	DefaultCharacterSelectorButton.grab_focus()

func HideAll() -> void:
	MainMenuContainer.visible = false
	LevelSelectContainer.visible = false
	CharacterSelector.visible = false
	OptionsMenuContainer.visible = false

func OnPlay() -> void:
	HideAll()
	LoadingScreen.visible = true
	LoadingScreen.Return()
	
	if LoadingScreen.StagePathsToStageNames.has(NextLevel.resource_path):
		var zoneText = str(LoadingScreen.StagePathsToStageNames[NextLevel.resource_path][0]).strip_edges()
		var actText = str(LoadingScreen.StagePathsToStageNames[NextLevel.resource_path][1]).strip_edges()
		LoadingScreen.SetTexts(zoneText, actText)
		
	if ResourceLoader.load_threaded_get_status(NextLevel.resource_path) == ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
		ResourceLoader.load_threaded_request(NextLevel.resource_path)
		CurrentlyLoadingScene = NextLevel.resource_path

func OnPlayPath(stagePath: String) -> void:
	NextLevel = ResourceLoader.load(stagePath)
	CheckpointSystem.Reset()
	CheckpointSystem.CheckpointScene = ProjectSettings.get_setting("application/run/main_scene")
	OnPlay()

func OnOptions() -> void:
	HideAll()
	OptionsMenuContainer.visible = true
	OptionsMenuContainer.SetDefaultFocus()

func OnQuit() -> void:
	get_tree().quit()

func PopulateLevelSelect() -> void:
	if SaveDataInstance == null and has_method("SaveData"): 
		SaveDataInstance = SaveData.Load()
		
	for stageDataNode in StagesData.get_children():
		var stage = stageDataNode as MainMenuStagesData
		if not (stage.UnlockedByDefault or SaveDataInstance.IsLevelUnlocked(stage.StageUniqueIdentifier)): 
			continue
			
		var newButton = StageTemplateButton.duplicate() as BaseButton
		var stageNameLabel = newButton.get_node("./HBoxContainer/StageName") as Label
		stageNameLabel.text = stage.StageName + "\n" + stage.ActName

		newButton.pressed.connect(func(): OnPlayPath(stage.ScenePath))

		var bestTimeString: String = "--:--:--"
		var bestRankString: String = "-"
		var characterName: String = "Sonic"

		if SaveDataInstance and SaveDataInstance.LevelSaves.has(stage.StageUniqueIdentifier):
			var stageSave = SaveDataInstance.LevelSaves[stage.StageUniqueIdentifier]
			if stageSave.BestTime.has(characterName):
				var total_seconds = stageSave.BestTime[characterName]
				var minutes = int(total_seconds) / 60
				var seconds = int(total_seconds) % 60
				var miliseconds = int((total_seconds - int(total_seconds)) * 100)
				bestTimeString = "%02d:%02d:%02d" % [minutes, seconds, miliseconds]

			if stageSave.BestRank.has(characterName):
				bestRankString = stageSave.BestRank[characterName]

			if stage.HasRedRings:
				newButton.get_node("./HBoxContainer/VBoxContainer/RedRings").visible = true
				for redring in range(1, 6):
					if stageSave.Items.get("RedRing" + str(redring), 0) > 0:
						newButton.get_node("./HBoxContainer/VBoxContainer/RedRings/RedRing" + str(redring)).texture = RedRingYesIcon
			else:
				newButton.get_node("./HBoxContainer/VBoxContainer/RedRings").visible = false

		newButton.get_node("./HBoxContainer/VBoxContainer/BestTime").text = "BEST TIME:   " + bestTimeString
		newButton.get_node("./HBoxContainer/VBoxContainer/BestRank").text = "BEST RANK:  " + bestRankString

		newButton.visible = true
		newButton.process_mode = PROCESS_MODE_INHERIT

		var target_container = LevelSelectContainer.get_child(0)
		target_container.add_child(newButton)
		target_container.move_child(newButton, target_container.get_child_count() - 2)
		
	StageTemplateButton.visible = false
	StageTemplateButton.process_mode = PROCESS_MODE_INHERIT
