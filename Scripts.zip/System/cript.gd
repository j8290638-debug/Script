# ApplyPlayerSettings.gd
class_name ApplyPlayerSettings
extends Node

@export var FpsDisplay: Control

func _ready() -> void:
	# فحص أمان ومحاكاة جلب كلاس الكاميرات المسجلة لتغيير مسافة الرندر
	if ClassDB.class_exists("PlayerCamera") or has_node("/root/PlayerCamera"):
		var camera_node = get_node_or_null("/root/PlayerCamera")
		if camera_node and "Instances" in camera_node:
			for cam in camera_node.Instances.values():
				if OptionsMenu.Options:
					cam.far = OptionsMenu.Options.RenderDistance

	if FpsDisplay and OptionsMenu.Options:
		FpsDisplay.visible = OptionsMenu.Options.ShowFps
		FpsDisplay.process_mode = PROCESS_MODE_INHERIT if OptionsMenu.Options.ShowFps else PROCESS_MODE_DISABLED
