# ApplyWorldEnvironmentSettings.gd
class_name ApplyWorldEnvironmentSettings
extends WorldEnvironment

func _ready() -> void:
	ApplySettings()

func ApplySettings() -> void:
	if environment:
		environment.ssr_enabled = false
		environment.ssao_enabled = false
		environment.ssil_enabled = false
		environment.sdfgi_enabled = false
		environment.glow_enabled = false
		environment.adjustment_enabled = false
