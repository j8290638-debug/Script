# SaveData.gd
class_name SaveData
extends Resource

const SaveFileName: String = "savedata_{0}.json"
static var SaveFileId: int = 0

var GameVersion: String = ""
var LevelSaves: Dictionary = {}
var GlobalItems: Dictionary = {}

# محاكاة الكلاس الداخلي للـ LevelSave بالسي شارب 1:1
class LevelSave:
	var Unlocked: bool = false
	var Items: Dictionary = {}
	var BestTime: Dictionary = {}
	var BestRank: Dictionary = {}

	func _init() -> void:
		Unlocked = false
		Items = {}
		BestTime = {}
		BestRank = {}

func _init() -> void:
	GameVersion = ProjectSettings.get_setting("application/config/version", "0.0.0")

static func Load() -> SaveData:
	var loadedSave = SaveData.new()
	var current_save_name = "user://" + "savedata_" + str(SaveFileId) + ".json"
	
	if not FileAccess.file_exists(current_save_name):
		return loadedSave
		
	var file = FileAccess.open(current_save_name, FileAccess.READ)
	if file:
		var json = JSON.new()
		if json.parse(file.get_as_text()) == OK:
			var data = json.data
			if data.has("GameVersion"): loadedSave.GameVersion = data["GameVersion"]
			if data.has("LevelSaves"): loadedSave.LevelSaves = data["LevelSaves"]
			if data.has("GlobalItems"): loadedSave.GlobalItems = data["GlobalItems"]
			return loadedSave
	return loadedSave

func Save() -> void:
	GameVersion = ProjectSettings.get_setting("application/config/version", "0.0.0")
	var current_save_name = "user://" + "savedata_" + str(SaveFileId) + ".json"
	
	var data = {
		"GameVersion": GameVersion,
		"LevelSaves": LevelSaves,
		"GlobalItems": GlobalItems
	}
	
	var file = FileAccess.open(current_save_name, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(data))

static func Erase() -> void:
	SaveData.new().Save()

func UnlockLevel(stageIdentifier: String) -> void:
	var stageSave = LevelSaves.get(stageIdentifier, { "Unlocked": false, "Items": {}, "BestTime": {}, "BestRank": {} })
	stageSave["Unlocked"] = true
	LevelSaves[stageIdentifier] = stageSave

func IsLevelUnlocked(stageIdentifier: String) -> bool:
	var stageSave = LevelSaves.get(stageIdentifier, { "Unlocked": false, "Items": {}, "BestTime": {}, "BestRank": {} })
	return stageSave.get("Unlocked", false)
