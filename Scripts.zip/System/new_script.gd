# StageData.gd
class_name StageData
extends Node

@export var StageZoneName: String
@export var StageActName: String
@export var Style: int = 0 # محاكاة للـ Enum: ActionStage=0, HubStage=1, SpecialStage=2
@export var StageUniqueIdentifier: String
@export var StageMusic: AudioStream
@export var HasRedRings: bool = false

var ElapsedTime: float = 0.0
@export var MaxTime: float = -1.0
@export var CountTime: bool = true
var IsFinished: bool = false

# Ranks
@export var SRankTime: float = 120.0
@export var SRankRings: int = 100
@export var SRankBlueSpheres: int = 0
@export var RankWeightTime: float = 0.8
@export var RankWeightRings: float = 0.2
@export var RankWeightSpheres: float = 0.0
@export var RankWeightDeath: float = 0.2

# Culling
@export var EnemyCullDistance: float = 200.0
@export var EnemyCulledVisibility: bool = false

@export var ItemCullDistance: float = 100.0
@export var ItemCulledVisibility: bool = false
const ItemDistancesCheckedAtOnce: int = 50
var ItemDistancesCheckStartFrom: int = 0

enum StageStyle {
	ActionStage,
	HubStage,
	SpecialStage
}

static var Instance: StageData

func _enter_tree() -> void:
	Instance = self

func _exit_tree() -> void:
	Instance = null

func _ready() -> void:
	if has_node("/root/MusicPlayerController") and get_node("/root/MusicPlayerController").Instance != null:
		var music_controller = get_node("/root/MusicPlayerController").Instance
		music_controller.MainMusic = StageMusic
		music_controller.SwitchMusicToMain()
	ItemDistanceCulling(true)

func _process(delta: float) -> void:
	if CountTime:
		ElapsedTime += delta
		
	if MaxTime > 0:
		if MaxTime - ElapsedTime < 0:
			for player in PlayerController.Instances:
				if Style == StageStyle.ActionStage and ClassDB.class_exists("CheckpointSystem"):
					get_node("/root/CheckpointSystem").Reset()
				
				var playerDamage = player.get_node_or_null("./PlayerControl/Damage")
				if playerDamage != null and not playerDamage.IsDead:
					playerDamage.Die()
			PlayerUI.CurrentTime = 0.0
		else:
			PlayerUI.CurrentTime = MaxTime - ElapsedTime
	else:
		PlayerUI.CurrentTime = ElapsedTime

	EnemyDistanceCulling()
	ItemDistanceCulling(false)

func EnemyDistanceCulling() -> void:
	if not ClassDB.class_exists("EnemyControl") and not has_node("/root/EnemyControl"): return
	var enemy_instances = get_node("/root/EnemyControl").Instances if has_node("/root/EnemyControl") else []
	
	for enemy in enemy_instances:
		var closeEnough: bool = false
		if enemy.get("DontCull"):
			closeEnough = true
			
		if not closeEnough:
			for player in PlayerController.Instances:
				if player.global_position.distance_to(enemy.RigidBody.global_position) <= EnemyCullDistance:
					closeEnough = true
					break
					
		if enemy.get("RigidBody"):
			var body = enemy.RigidBody
			body.process_mode = PROCESS_MODE_INHERIT if closeEnough else PROCESS_MODE_DISABLED
			body.set_physics_process(closeEnough)
			body.visible = closeEnough or EnemyCulledVisibility

func ItemDistanceCulling(firstrun: bool) -> void:
	if not ClassDB.class_exists("CollectableItem") and not has_node("/root/CollectableItem"): return
	var item_instances = get_node("/root/CollectableItem").Instances if has_node("/root/CollectableItem") else []
	
	if item_instances.size() == 0: return
	if ItemDistancesCheckStartFrom >= item_instances.size() or firstrun:
		ItemDistancesCheckStartFrom = 0

	var endItem: int = item_instances.size() if firstrun else clampi(ItemDistancesCheckStartFrom + ItemDistancesCheckedAtOnce, 0, item_instances.size())

	for i in range(ItemDistancesCheckStartFrom, endItem):
		var item = item_instances[i]
		var closeEnough: bool = false
		if item.get("DontCull") or item.get("AttractiveNode") != null:
			closeEnough = true
			
		if not closeEnough:
			for player in PlayerController.Instances:
				if player.global_position.distance_to(item.global_position) <= ItemCullDistance:
					closeEnough = true
					break
					
		item.process_mode = PROCESS_MODE_INHERIT if closeEnough else PROCESS_MODE_DISABLED
		item.set_physics_process(closeEnough)
		item.visible = closeEnough or ItemCulledVisibility

	ItemDistancesCheckStartFrom = ItemDistancesCheckStartFrom + ItemDistancesCheckedAtOnce
